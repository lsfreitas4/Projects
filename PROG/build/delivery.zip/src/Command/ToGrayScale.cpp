#include "Command/ToGrayScale.hpp"
#include "Image.hpp"
#include "Color.hpp"

namespace prog {

    /**
     * @brief Construtor da classe ToGrayScale.
     *
     * Inicializa o comando para converter a imagem para tons de cinzento.
     */
    ToGrayScale::ToGrayScale() : Command("to_gray_scale") {}

    /**
     * @brief Aplica a conversão da imagem para tons de cinzento.
     *
     * Para cada pixel da imagem, calcula a média dos valores RGB e substitui
     * o pixel pelo valor de cinzento correspondente.
     * Se a imagem for nullptr, retorna nullptr.
     *
     * @param img Ponteiro para a imagem a ser convertida.
     * @return Ponteiro para a imagem modificada.
     *         Retorna nullptr se img for nullptr.
     */
    Image* ToGrayScale::apply(Image* img) {
        if (img == nullptr) return nullptr;

        for (int y = 0; y < img->height(); y++) {
            for (int x = 0; x < img->width(); x++) {
                Color original = img->at(x, y);
                int gray_value = (original.red() + original.green() + original.blue()) / 3;
                Color gray(gray_value, gray_value, gray_value);
                img->at(x, y) = gray;
            }
        }

        return img;
    }

}
