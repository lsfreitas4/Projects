#include "Command/HMirror.hpp"
#include "Image.hpp"
#include <algorithm> // For std::swap

namespace prog {

    /**
     * @brief Construtor da classe HMirror.
     *
     * Inicializa o comando para espelhar horizontalmente uma imagem.
     */
    HMirror::HMirror() : Command("h_mirror") {}

    /**
        * @brief executa o comando de espelhamento horizontal na imagem.
        *
        * Inverte horizontalmente os pixels da imagem, trocando os pixels da esquerda
        * pelos correspondentes da direita.
        *
        * @param img Ponteiro para a imagem a ser espelhada.
        * @return Retorna o mesmo ponteiro para a imagem modificada.
        *         Se  'img' for nullptr, retorna nullptr.
        */
    Image* HMirror::apply(Image* img) {
        if (img == nullptr) {
            return nullptr;
        }

        int width = img->width();
        int height = img->height();
        int half_width = width / 2;

        // Para cada linha, troca os pixels da esquerda com os da direita
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < half_width; x++) {
                int mirror_x = width - 1 - x;
                std::swap(img->at(x, y), img->at(mirror_x, y));
            }
        }

        return img;
    }

}
