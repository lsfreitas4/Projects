#include "schedule.h"
#include "readFromTextFiles.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <string>

std::vector<pair<Blocks, pair<std::string, std::string>>> Schedule::getSchedule(){
    return this->schedule;
}

void Schedule::addPairSch(const pair<Blocks,pair<std::string,std::string>>& ucCode){
    schedule.push_back(ucCode);
}

const _Rb_tree_const_iterator<ClassesPerUc> Schedule::searchUc(const ClassesPerUc &classesPerUc) const {
    auto finder = myClasses.find(classesPerUc);
    return finder;
}

void Schedule::printDetailsUcClass(const ClassesPerUc& classesPerUc) const {
    const _Rb_tree_const_iterator<ClassesPerUc> classesuc = searchUc(classesPerUc);
    if (classesuc == myClasses.end()) {
        cout << "Turma nao encontrada." << endl;
        return;
    }
    cout << "A turma " << classesuc->getClassCode() << " da UC " << classesuc->getUcCode() << " tem " << classesuc->getNumStudents() << " estudantes inscritos." << endl;
}

void Schedule::printSch(int studentCode){
    Students student = Students(studentCode, "");
    auto position = students.find(student);
    if(position == students.end()) {
        std::cout << "Student not found!\n Try again.\n" << endl;
        return;
    }

    student = *position;
    vector<pair<Blocks,pair<std::string,std::string>>> S;
    schedule = S;
    student.loadStudentSchedule(*this);
    sort(schedule.begin(), schedule.end());
    std::cout << "\nHorário de " << student.getStudentCode() << "\n";
    for (pair<Blocks,pair<std::string,std::string>> pair : schedule) {
        std::cout << pair.second.first << ':' << pair.second.second << ':';
        std::cout << "       " << pair.first.getWeekDay() << " , " << pair.first.getType() << " , " << pair.first.getDuration() << " , " << pair.first.getStartHour() << std::endl;
    }

}

bool Schedule::validSched() const {
    for (size_t i = 0; i < schedule.size()-1; i++) {
        for (size_t j = i+1; j < schedule.size(); j++) {
            if (schedule[i].first.getWeekDay() != schedule[j].first.getWeekDay()) continue;
            if (schedule[i].first.getType() == "T" || schedule[j].first.getType() == "T") continue;
            if (schedule[i].first.getStartHour() == schedule[j].first.getStartHour()) return false;
            if (schedule[i].first.getStartHour() < schedule[j].first.getStartHour() && schedule[j].first.getStartHour() < schedule[i].first.getStartHour()+schedule[i].first.getDuration()) return false;
        }
    }
    return true;
}