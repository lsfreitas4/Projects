#ifndef READFROMTEXTFILES_H
#define READFROMTEXTFILES_H

#include <string>
#include <set>

#include "classesPerUc.h"
#include "students.h"
#include "blocks.h"
#include "schedule.h"

class Students;
class ClassesPerUc;
class Blocks;
class Schedule;

/*!
 * Class that is used to read all the csv files given.
 */
class ReadFromTextFiles {
private:
    /*!
     * Balanced binary tree of students read from the file students_classes.csv.
     */
    std::set<Students> students;
    /*!
     * Balanced binary tree with classes and ucs read from the file classes_per_uc.csv
     */
    std::set<ClassesPerUc> classesPUC;
    /*!
     * Vector with the blocks of classes of a schedule.
     */
    std::vector<Blocks> scheduleBlocks;

public:
    /*!
     * Empty constructor.
     */
    ReadFromTextFiles();
    /*!
     * Deals and stores the studets and it's information in a balanced binary tree.
     * @param fileName - the name of the file to read
     */
    void studentClassParser(std::string fileName);
    /*!
     * Deals and stores the classes per UC in a binary binary tree.
     * @param fileName - the name of the file to read
     */
    void classesClassParser(std::string fileName);
    /*!
     * Returns the balanced binary tree of students.
     * @return - balanced binary tree of students
     * Complexity: O(1)
     */
    std::set<Students> getStudents();
    /*!
     * Returns the balanced binary tree of classes per UC.
     * @return - balanced binary tree of classes per UC
     * Complexity: O(1)
     */
    std::set<ClassesPerUc> getClassesPerUc();
};

#endif //READFROMTEXTFILES_H
