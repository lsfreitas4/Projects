#include "Command/Add.hpp"
#include "Command/Open.hpp"
#include "Image.hpp"

namespace prog {
    /**
     * @brief Construtor da classe Add.
     *
     * Inicializa o comando de adicionar uma imagem a outra.
     *
     * @param filename Nome do ficheiro da imagem a adicionar.
     * @param neutral Cor considerada neutra, pixels desta cor são ignorados.
     * @param x Coordenada x onde a imagem será adicionada.
     * @param y Coordenada y onde a imagem será adicionada.
     */

    Add::Add(const std::string& filename, const Color& neutral, int x, int y) :
        Command("add"), filename_(filename), neutral_(neutral), x_(x), y_(y) {}

    /**
    * @brief Aplica o comando de adicionar uma imagem sobre outra.
    *
    * Adiciona a imagem do ficheiro 'filename' à imagem 'img', na posição x, y).
    * Pixels da imagem a adicionar que tenham a cor neutra não sobrescrevem.
    *
    * @param img Ponteiro para a imagem base onde se vai adicionar a nova imagem.
    * @return Ponteiro para a imagem resultante, mesmo ponteiro 'img' passado.
    *         Se img for nullptr, retorna nullptr.
    */
    Image* Add::apply(Image* img) {
        if (img == nullptr) {
            return nullptr;
        }

        // Abre a imagem a adicionar
        command::Open opener(filename_);
        Image* toAdd = opener.apply(nullptr);
        if (toAdd == nullptr) {
            return img;
        }

        int imgWidth = img->width();
        int imgHeight = img->height();
        int addWidth = toAdd->width();
        int addHeight = toAdd->height();

        // Percorre todos os pixels da imagem a adicionar
        for (int ay = 0; ay < addHeight; ay++) {
            int targetY = y_ + ay;
            if (targetY < 0 || targetY >= imgHeight) continue;

            for (int ax = 0; ax < addWidth; ax++) {
                int targetX = x_ + ax;
                if (targetX < 0 || targetX >= imgWidth) continue;

                Color addColor = toAdd->at(ax, ay);
                // Ignora pixels com cor neutra
                if (!(addColor.red() == neutral_.red() &&
                      addColor.green() == neutral_.green() &&
                      addColor.blue() == neutral_.blue())) {
                    img->at(targetX, targetY) = addColor;
                      }
            }
        }

        delete toAdd;
        return img;
    }

}