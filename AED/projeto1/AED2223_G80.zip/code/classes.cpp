#include "classes.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <list>

Classes::Classes() {
    this->classCode;
    this->ucCode;
    this->weekDay;
    this->startHour;
    this->duration;
    this->type;
    this->classes;
}

Classes::Classes(std::string classCode, std::string ucCode, std::string weekDay, float startHour, float duration,
                 std::string type) : classCode(classCode), ucCode(ucCode), weekDay(weekDay), startHour(startHour),
                 duration(duration), type(type) {}

void Classes::setClassCode(std::string classCode) {
    this->classCode=classCode;
}

std::string Classes::getClassCode() const {
    return this->classCode;
}

void Classes::setUcCode(std::string ucCode) {
    this->ucCode=ucCode;
}

std::string Classes::getUcCode() const {
    return this->ucCode;
}

void Classes::setWeekDay(std::string weekDay) {
    this->weekDay=weekDay;
}

std::string Classes::getWeekDay() const {
    return this->weekDay;
}

void Classes::setStartHour(float startHour) {
    this->startHour=startHour;
}

float Classes::getStartHour() const {
    return this->startHour;
}

void Classes::setDuration(float duration) {
    this->duration=duration;
}

float Classes::getDuration() const {
    return this->duration;
}

void Classes::setType(std::string type) {
    this->type=type;
}

std::string Classes::getType() const {
    return this->type;
}
