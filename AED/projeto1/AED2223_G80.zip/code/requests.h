#ifndef REQUESTS_H
#define REQUESTS_H

#include "classesPerUc.h"
#include <string>

/*!
 * Class that takes care of the requests made by the students.
 */
class Requests {
private:
    /*!
     * The unique code of a student.
     */
    int studentCode;
    /*!
     *
     */
    std::string add;
    /*!
     *
     */
    std::string remove;
    /*!
     *
     */
    int option;
public:
    /*!
     * Constructor of a Request. Contains an integer student code, the strings add and remove and the integer options.
     * @param studentCode
     * @param add
     * @param remove
     * @param option
     * Complexity: O(1)
     */
    Requests(int studentCode, std::string add, std::string remove, int option);
    /*!
     * Returns the unique code of the student that made the request.
     * @return studentCode of a student
     */
    int getStudentCode();
    /*!
     * Returns
     * @return
     */
    std::string addRequest();
    /*!
     *
     * @return
     */
    std::string removeRequest();
    /*!
     *
     * @return
     */
    int optionRequest();
};
#endif //REQUESTS_H
