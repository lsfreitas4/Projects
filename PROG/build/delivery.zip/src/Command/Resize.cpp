#include "Command/Resize.hpp"
#include "Image.hpp"
#include "Color.hpp"

using namespace std;

namespace prog {
    /**
     * @brief Construtor da classe Resize.
     *
     * Inicializa o comando para redimensionar a imagem, criando uma nova imagem
     * de dimensão (w x h), começando a copiar a partir do ponto (x, y) da imagem original.
     *
     * @param x Coordenada x inicial da região a copiar da imagem original.
     * @param y Coordenada y inicial da região a copiar da imagem original.
     * @param width Nova largura da imagem redimensionada.
     * @param height Nova altura da imagem redimensionada.
     */
    Resize::Resize(int x, int y, int width, int height) : Command("resize"), x_(x), y_(y), w_(width), h_(height) {}

    /**
     * @brief Aplica o comando de redimensionamento na imagem.
     *
     * Cria uma nova imagem com as dimensões indicadas e copia os pixels da região
     * especificada da imagem original para a nova imagem.
     * As áreas da nova imagem que não forem preenchidas são inicializadas com branco.
     * Se a imagem for nullptr ou as dimensões forem (0,0), não faz alterações.
     *
     * @param img Ponteiro para a imagem original.
     * @return Ponteiro para a nova imagem redimensionada.
     *         A imagem original é eliminada.
     *         Se img for nullptr, retorna nullptr.
     */
    Image* Resize::apply(Image* img) {
        if(img == nullptr || (w_ == 0 && h_ == 0)) {
            return img;
        }

        int imgwidth= img->width();
        int imgheight= img->height();

        Color fill(255, 255, 255);

        Image* resizeimg= new Image(w_, h_, fill);

        int resizex= max(x_, 0);
        int resizey= max(y_, 0);
        int resizewidth= min(w_, imgwidth - resizex);
        int resizeheight= min(h_, imgheight - resizey);

        resizewidth= max(resizewidth, 0);
        resizeheight= max(resizeheight, 0);

        for (int y= 0; y < resizeheight; ++y) {
            for (int x= 0; x < resizewidth; ++x) {
                int dest_x= x;
                int dest_y= y;
                if (resizex + x < imgwidth && resizey + y < imgheight) {
                    resizeimg->at(dest_x, dest_y)= img->at(resizex + x, resizey + y);
                }
            }
        }

        delete img;
        return resizeimg;
    }
}
