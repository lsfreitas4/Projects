#include "Command/Crop.hpp"
#include "Image.hpp"
#include "Color.hpp"

using namespace std;

namespace prog {

    /**
     * @brief Construtor da classe Crop.
     *
     * Inicializa o comando de recorte (crop) de uma imagem.
     *
     * @param x Coordenada x do canto superior esquerdo do recorte.
     * @param y Coordenada y do canto superior esquerdo do recorte.
     * @param width Largura da área a recortar.
     * @param height Altura da área a recortar.
     */
    Crop::Crop(int x, int y, int width, int height) : Command("crop"), x_(x), y_(y), w_(width), h_(height) {}

    /**
     * @brief Aplica o comando de recorte numa imagem.
     *
     * Cria uma nova imagem que corresponde a uma sub-região da imagem original,
     * definida pelas coordenadas e dimensões do recorte.
     *
     * @param img Ponteiro para a imagem a recortar.
     * @return Ponteiro para a nova imagem recortada.
     *         Se  'img' for nullptr, retorna nullptr.
     *         Se o recorte não for válido, retorna uma imagem vazia (0x0).
     */
    Image* Crop::apply(Image* img) {
        if(img == nullptr || (w_ == 0 && h_ == 0)) {
            return img;
        }

        int imgwidth= img->width();
        int imgheight= img->height();

        // Calcula os limites válidos do recorte
        int cropx= max(x_, 0);
        int cropy= max(y_, 0);
        int cropwidth= min(w_, imgwidth - cropx);
        int cropheight= min(h_, imgheight - cropy);

        cropwidth= max(cropwidth, 0);
        cropheight= max(cropheight, 0);

        // Se a área de recorte for inválida, retorna uma imagem vazia
        if (cropwidth <= 0 || cropheight <= 0) {
            delete img;
            return new Image(0, 0);
        }

        // Cria a nova imagem com as dimensões do recorte
        Image* cropimg = new Image(cropwidth, cropheight);

        // Copia os pixels da área de recorte para a nova imagem
        for (int y= 0; y < cropheight; ++y) {
            for (int x= 0; x < cropwidth; ++x) {
                cropimg->at(x, y)= img->at(cropx + x, cropy + y);
            }
        }

        // Liberta a imagem original e retorna a nova imagem recortada
        delete img;
        return cropimg;
    }

}
