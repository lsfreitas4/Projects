#ifndef SCHEDULE_H
#define SCHEDULE_H

#include "students.h"
#include "classesPerUc.h"
#include "blocks.h"
#include "readFromTextFiles.h"
#include <string>
#include <vector>
#include <list>
#include <set>
#include <algorithm>

class ClassesPerUc;
class Students;
class Blocks;
class ReadFromTextFiles;

class Schedule {
private:
    std::vector<pair<Blocks, pair<std::string, std::string>>> schedule;
    set<ClassesPerUc> myClasses;
    set<Students>students;
public:
    std::vector<pair<Blocks, pair<std::string, std::string>>> getSchedule();
    const _Rb_tree_const_iterator<ClassesPerUc> searchUc(const ClassesPerUc &classesPerUc) const;
    void printDetailsUcClass(const ClassesPerUc& classesPerUc) const;
    void printSch(int studentCode);
    void addPairSch(const pair<Blocks,pair<std::string,std::string>>& ucCode);
    bool validSched() const;
};

#endif //SCHEDULE_H
