#include "Command/RotateLeft.hpp"
#include "Image.hpp"

using namespace std;

namespace prog {
    /**
     * @brief Construtor da classe RotateLeft.
     *
     * Inicializa o comando para rodar a imagem 90 graus para a esquerda.
     */
    RotateLeft::RotateLeft() : Command("rotate_left") {}

    /**
     * @brief Aplica o comando de rotação à esquerda na imagem.
     *
     * Cria uma nova imagem com largura e altura trocadas e
     * copia os pixels da imagem original rotacionando-os 90 graus no sentido anti-horário.
     * A imagem original é eliminada.
     *
     * @param img Ponteiro para a imagem a ser rotacionada.
     * @return Ponteiro para a nova imagem rotacionada.
     *         Retorna nullptr se img for nullptr.
     */
    Image* RotateLeft::apply(Image* img) {
        if (img == nullptr) {
            return nullptr;
        }

        int width= img->width();
        int height= img->height();

        Image* rotate= new Image(height, width);

        for (int y= 0; y < height; y++) {
            for (int x= 0; x < width; x++) {
                rotate->at(y, width - 1 - x) = img->at(x, y);
            }
        }

        delete img;
        return rotate;
    }
}
