#include "requests.h"

#include <string>

Requests::Requests() {}

Requests::Requests(int stdCode, std::string a, std::string rem, int opt) {
    this->studentCode=stdCode;
    this->add=a;
    this->remove=rem;
    this->option=opt;
}

int Requests::getStudentCode() {
    return this->studentCode;
}

std::string Requests::addRequest() {
    return this->add;
}

std::string Requests::removeRequest() {
    return this->remove;
}

int Requests::optionRequest() {
    return this->option;
}