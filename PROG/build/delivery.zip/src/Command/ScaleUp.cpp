#include "Command/ScaleUp.hpp"
#include "Image.hpp"

using namespace std;

namespace prog {
    /**
     * @brief Construtor da classe ScaleUp.
     *
     * Inicializa o comando para ampliar a imagem por fatores x e y.
     *
     * @param x Fator de ampliação na largura.
     * @param y Fator de ampliação na altura.
     */
    ScaleUp::ScaleUp(int x, int y) : Command("scaleup"), x_(x), y_(y) {}

    /**
     * @brief Aplica o comando de ampliação na imagem.
     *
     * Cria uma nova imagem com dimensões aumentadas multiplicando a largura e altura pelos fatores x e y,
     * copiando cada pixel da imagem original para uma região ampliada na nova imagem.
     * Se a imagem for nullptr ou se algum dos fatores for menor ou igual a zero, não altera a imagem.
     *
     * @param img Ponteiro para a imagem original.
     * @return Ponteiro para a nova imagem ampliada.
     *         A imagem original é eliminada.
     *         Retorna nullptr se img for nullptr.
     */
    Image* ScaleUp::apply(Image* img) {
        if (img == nullptr || x_ <= 0 || y_ <= 0) {
            return img;
        }

        int imgwidth= img->width();
        int imgheight= img->height();
        int scalewidth= imgwidth * x_;
        int scaleheight= imgheight * y_;

        Image* scaleimg= new Image(scalewidth, scaleheight);

        for (int y= 0; y < imgheight; y++) {
            for (int x= 0; x < imgwidth; x++) {
                Color originalpixel= img->at(x, y);
                for (int w= 0; w < y_; w++) {
                    for (int z= 0; z < x_; z++) {
                        int scalex= x * x_ + z;
                        int scaley= y * y_ + w;
                        scaleimg->at(scalex, scaley) = originalpixel;
                    }
                }
            }
        }

        delete img;
        return scaleimg;
    }
}
