#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <list>

#include "bst.h"
#include "students.h"
#include "readFromTextFiles.h"
#include "classesPerUc.h"

ReadFromTextFiles::ReadFromTextFiles(){}

void ReadFromTextFiles::studentClassParser(std::string fileName){
    ifstream ifstr("*/students_classes.csv");
    std::string line;
    getline(ifstr, line);

    std::vector<Students> aux;
    while(getline(ifstr, line)){
        std::string studentCode, studentName, ucCode, classCode;
        istringstream iss(line);

        // get studentCode                            get studentName
        getline(iss, studentCode, ','); getline(iss, studentName, ',');
        // get ucCode                            get classCode
        getline(iss, ucCode, ','); getline(iss, classCode, ',');

        // turn student code to an integer instead of string
        int stdCode = stoi(studentCode);

        ClassesPerUc classesPerUc = ClassesPerUc(ucCode, classCode);

        if(aux[aux.size()-1].getStudentCode() != stdCode || aux.empty()){
            Students st = Students(stdCode, studentName);
            st.addClasses(classesPerUc);
            aux.push_back(st);
        }
        else
            aux[aux.size()-1].addClasses(classesPerUc);

        auto position = myClasses.find(classesPerUc);

        if(position != myClasses.end()){
            ClassesPerUc aux1 = *position;
            myClasses.erase(position);
            aux1.increment();
            myClasses.insert(aux1);
        }
    }
    students = std::set<Students> (aux.begin(), aux.end());
}

void ReadFromTextFiles::classesClassParser(std::string fileName){
    ifstream ifstr("classes.csv");
    std::string line;
    getline(ifstr, line);

    std::vector<ClassesPerUc> aux;
    while(getline(ifstr, line)){
        std::string classCode, ucCode, weekDay, startHourT, durationT, type;
        istringstream iss(line);
        // get class code                            get uc code
        getline(iss, classCode, ','); getline(iss, ucCode, ',');
        // get week day                           get start hour
        getline(iss, ucCode, ','); getline(iss, startHourT, ',');
        // get duration                           get type
        getline(iss, durationT, ','); getline(iss, type, ',');

        // turn student code to an integer instead of string
        float startHour = stof(startHourT);
        float duration = stof(durationT);

        Blocks b = Blocks(weekDay, startHour, duration, type);

        if(aux[aux.size()-1].getUcCode() != ucCode || aux.empty()){
            ClassesPerUc cpuc = ClassesPerUc(ucCode, classCode);
            cpuc.addBlock(b);
            aux.push_back(cpuc);
        }
        else{
            // while no error and last ucCode saved isn't the current ucCode
            unsigned pos = aux.size()-1;
            while(pos != -1 && aux[pos].getUcCode() != ucCode){
                if(aux[pos].getClassCode() == classCode){
                    aux[pos].addBlock(b);
                    break;
                }
                pos++;
            }
            if (aux[pos].getUcCode() != ucCode && pos != -1){
                ClassesPerUc classesPerUc = ClassesPerUc(ucCode, classCode);
                classesPerUc.addBlock(b);
                aux.push_back(classesPerUc);
            }
        }
    }
    myClasses = std::set<ClassesPerUc> (aux.begin(), aux.end());
}


std::set<Students> ReadFromTextFiles::getStudents() {
    return this->students;
}

std::set<ClassesPerUc> ReadFromTextFiles::getClassesPerUc() {
    return this->myClasses;
}
