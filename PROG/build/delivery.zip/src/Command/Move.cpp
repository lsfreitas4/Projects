#include "Command/Move.hpp"
#include "Image.hpp"
#include "Color.hpp"
#include <vector>

namespace prog {
    /**
    * @brief Construtor da classe Move.
    *
    * Inicializa o comando para mover a imagem numa direção.
    *
    * @param x Deslocamento horizontal (positivo para a direita, negativo para a esquerda).
    * @param y Deslocamento vertical (positivo para baixo, negativo para cima).
    */

    Move::Move(int x, int y) : Command("move"), x_(x), y_(y) {}

    /**
     * @brief Aplica o comando de deslocamento na imagem.
     *
     * Move a imagem pelos valores x e y, preenchendo as áreas descobertas com branco.
     * Caso o deslocamento seja (0,0) ou a imagem seja nullptr, não altera nada.
     *
     * @param img Ponteiro para a imagem a ser movida.
     * @return Retorna o mesmo ponteiro para a imagem atualizada.
     */
    Image* Move::apply(Image* img) {
        if (img == nullptr || (x_ == 0 && y_ == 0)) {
            return img;
        }

        int width = img->width();
        int height = img->height();

        // Guarda uma cópia dos pixels originais
        std::vector<std::vector<Color>> original;
        for (int y = 0; y < height; y++) {
            std::vector<Color> row;
            for (int x = 0; x < width; x++) {
                row.push_back(img->at(x, y));
            }
            original.push_back(row);
        }

        // Preenche toda a imagem com branco
        Color fill(255, 255, 255);
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                img->at(x, y) = fill;
            }
        }

        // Copia os pixels da imagem original para a nova posição
        for (int y = 0; y < height; y++) {
            int newY = y + y_;
            if (newY < 0 || newY >= height) continue;

            for (int x = 0; x < width; x++) {
                int newX = x + x_;
                if (newX < 0 || newX >= width) continue;

                img->at(newX, newY) = original[y][x];
            }
        }

        return img;
    }

}