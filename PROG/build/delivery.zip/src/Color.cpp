/**
* @file Color.cpp
 * @brief Implementação da classe prog::Color, que representa uma cor RGB com 8 bits por canal.
 *
 * Contém os construtores, métodos de acesso e operadores para leitura e escrita das cores
 * a partir de ficheiros e scrims. Cada cor é composta por três valores inteiros (0 a 255),
 * correspondentes ao vermelho, verde e azul.
 */
#include "Color.hpp"
#include <iostream>

using std::istream;

namespace prog {
    /**
     * @brief Construtor por omissão.
     *
    * Cria uma cor preta com valores (0, 0, 0).
    */
    Color::Color() : red_val(0), green_val(0), blue_val(0) {}

    /**
    * @brief Construtor de cópia.
    *
     * Cria uma nova cor com os mesmos valores de outra cor.
    *
    * @param other Cor a copiar.
    */
    Color::Color(const Color &other) : red_val(other.red_val), green_val(other.green_val), blue_val(other.blue_val) {}

    /**
     * @brief Construtor com valores RGB.
     *
     * Cria uma nova cor com os valores especificados para vermelho, verde e azul.
     *
     * @param r Valor do canal vermelho.
     * @param g Valor do canal verde.
     * @param b Valor do canal azul.
     */
    Color::Color(rgb_value r, rgb_value g, rgb_value b) : red_val(r), green_val(g), blue_val(b) {}

    /**
     * @brief Obtém o valor do canal vermelho (constante).
     * @return Valor do canal vermelho.
     */
    rgb_value Color::red() const {
        return red_val;
    }

    /**
     * @brief Obtém o valor do canal verde (constante).
     * @return Valor do canal verde.
     */
    rgb_value Color::green() const {
        return green_val;
    }

    /**
     * @brief Obtém o valor do canal azul (constante).
     * @return Valor do canal azul.
     */
    rgb_value Color::blue() const {
        return blue_val;
    }

    /**
     * @brief Obtém referência ao canal vermelho (modificável).
     * @return Referência ao valor do canal vermelho.
     */
    rgb_value &Color::red() {
        return red_val;
    }

    /**
     * @brief Obtém referência ao canal verde (modificável).
     * @return Referência ao valor do canal verde.
     */
    rgb_value &Color::green() {
        return green_val;
    }

    /**
     * @brief Obtém referência ao canal azul (modificável).
     * @return Referência ao valor do canal azul.
     */
    rgb_value &Color::blue() {
        return blue_val;
    }
}

/**
 * @brief Operador de extração para ler uma cor de um stream.
 *
 * Lê três inteiros correspondentes aos canais vermelho, verde e azul e atualiza o objeto Color.
 *
 * @param input Stream de entrada.
 * @param c Objeto Color a preencher.
 * @return Referência para o stream de entrada.
 */
// Use to read color values from a script file.
istream &operator>>(istream &input, prog::Color &c) {
    int r, g, b;
    input >> r >> g >> b;
    c.red() = r;
    c.green() = g;
    c.blue() = b;
    return input;
}

std::ostream &operator<<(std::ostream &output, const prog::Color &c) {
    output << (int) c.red() << ":" << (int) c.green() << ":" << (int) c.blue();
    return output;
}
