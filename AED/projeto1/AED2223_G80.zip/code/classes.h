#ifndef CLASSES_H
#define CLASSES_H

#include <string>
#include <vector>
#include <list>
#include "bst.h"


class Classes {
private:
    std::string classCode;
    std::string ucCode;
    std::string weekDay;
    float startHour;
    float duration;
    std::string type;
    vector<Classes> *classes;

public:
    Classes();
    Classes(std::string classCode, std::string ucCode, std::string weekDay, float startHour, float duration, std::string type);
    void setClassCode(std::string classCode);
    std::string getClassCode() const;
    void setUcCode(std::string ucCode);
    std::string getUcCode() const;
    void setWeekDay(std::string weekDay);
    std::string getWeekDay() const;
    void setStartHour(float startHour);
    float getStartHour() const;
    void setDuration(float duration);
    float getDuration() const;
    void setType(std::string type);
    std::string getType() const;
};

#endif //CLASSES_H
