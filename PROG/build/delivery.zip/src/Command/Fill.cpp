#include "Command/Fill.hpp"
#include "Image.hpp"

namespace prog {

    /**
     * @brief Construtor da classe Fill.
     *
     * Inicializa o comando para preencher uma região retangular da imagem com uma cor.
     *
     * @param x Coordenada x do canto superior esquerdo da região a preencher.
     * @param y Coordenada y do canto superior esquerdo da região a preencher.
     * @param w Largura da região a preencher.
     * @param h Altura da região a preencher.
     * @param color Cor usada para preencher a região.
     */
    Fill::Fill(int x, int y, int w, int h, const Color& color) :
        Command("fill"), x_(x), y_(y), w_(w), h_(h), color_(color) {}

    /**
     * @brief Aplica o comando de preenchimento na imagem.
     *
     * Preenche a região definida pelo retângulo (x, y, w, h) com a cor 'color'.
     * Apenas os pixels dentro dos limites da imagem são modificados.
     *
     * @param img Ponteiro para a imagem onde será aplicado o preenchimento.
     * @return Retorna o mesmo ponteiro para a imagem modificada.
     *         Se 'img' for nullptr, retorna nullptr.
     */
    Image* Fill::apply(Image* img) {
        if (img == nullptr) {
            return nullptr;
        }

        int img_width = img->width();
        int img_height = img->height();

        // Calcula os limites da região a preencher, garantindo que ficam dentro da imagem
        int x_end = std::min(x_ + w_, img_width);
        int y_end = std::min(y_ + h_, img_height);

        if (x_ < img_width && y_ < img_height) {
            for (int y = std::max(y_, 0); y < y_end; y++) {
                for (int x = std::max(x_, 0); x < x_end; x++) {
                    img->at(x, y) = color_;
                }
            }
        }

        return img;
    }

}
