#include "Command/RotateRight.hpp"
#include "Image.hpp"

using namespace std;

namespace prog {
    /**
     * @brief Construtor da classe RotateRight.
     *
     * Inicializa o comando para rodar a imagem 90 graus para a direita.
     */
    RotateRight::RotateRight() : Command("rotate_right") {}

    /**
     * @brief Aplica o comando de rotação à direita na imagem.
     *
     * Cria uma nova imagem com as dimensões invertidas e
     * copia os pixels da imagem original rotacionando-os 90 graus no sentido horário.
     * A imagem original é eliminada.
     *
     * @param img Ponteiro para a imagem a ser rotacionada.
     * @return Ponteiro para a nova imagem rotacionada.
     *         Retorna nullptr se img for nullptr.
     */
    Image* RotateRight::apply(Image* img) {
        if (img == nullptr) {
            return nullptr;
        }

        int width= img->width();
        int height= img->height();

        Image* rotate= new Image(height, width);

        for (int y= 0; y < height; y++) {
            for (int x= 0; x < width; x++) {
                rotate->at(height - 1 - y, x) = img->at(x, y);
            }
        }

        delete img;
        return rotate;
    }
}
