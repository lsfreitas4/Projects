#include "blocks.h"

Blocks::Blocks(const std::string& wDay, float sHour, float dur, const std::string& ty) {
    this->weekDay=wDay;
    this->startHour=sHour;
    this->duration=dur;
    this->type=ty;
}

std::string Blocks::getWeekDay() const {
    return this->weekDay;
}

float Blocks::getStartHour() const{
    return this->startHour;
}

float Blocks::getDuration() const {
    return this->duration;
}

std::string Blocks::getType() const {
    return this->type;
}


bool Blocks::operator<(Blocks blocks){
    if(weekDay==blocks.getWeekDay()) {
        if(startHour==blocks.getStartHour())
            return duration < blocks.getDuration();
    }

    if(weekDay=="Monday")
        return (blocks.getWeekDay()=="Tuesday" || blocks.getWeekDay()=="Wednesday" ||
            blocks.getWeekDay()=="Thursday" || blocks.getWeekDay()=="Friday");

    if (weekDay=="Tuesday")
        return (blocks.getWeekDay()=="Wednesday" || blocks.getWeekDay()=="Thursday" ||
            blocks.getWeekDay()=="Friday");

    if (weekDay=="Wednesday")
        return (blocks.getWeekDay()=="Thursday" || blocks.getWeekDay()=="Friday" );

    if (weekDay=="Thursday")
        return (blocks.getWeekDay()=="Friday");

    else return blocks.getWeekDay()=="Saturday";
}
