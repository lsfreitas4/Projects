#include "Image.hpp"

using namespace std;

namespace prog {
    /**
    * @brief Construtor da classe Image.
    *
    * Inicializa uma imagem com largura w, altura h e preenche todos os pixels
    * com fill.
    *
    * @param w Largura da imagem.
    * @param h Altura da imagem.
    * @param fill Cor usada para preencher todos os pixels da imagem.
    */
    Image::Image(int w, int h, const Color &fill) : width_val(w), height_val(h), pixels_val(h, vector<Color>(w, fill)) {}

    /**
     * @brief Destrutor da classe Image.
     */
    Image::~Image() {
    }

    /**
     * @brief Obtém a largura da imagem.
     *
     * @return A largura da imagem em pixels.
     */
    int Image::width() const {
        return width_val;
    }

    /**
     * @brief Obtém a altura da imagem.
     *
     * @return A altura da imagem em pixels.
     */
    int Image::height() const {
        return height_val;
    }

    /**
     * @brief Obtém uma referência ao pixel numa dada posição (x, y).
     *
     * Permite modificar a cor do pixel.
     *
     * @param x Coordenada x (coluna) do pixel.
     * @param y Coordenada y (linha) do pixel.
     * @return Referência ao objeto Color na posição (x, y).
     */
    Color &Image::at(int x, int y) {
        return pixels_val[y][x];
    }
    /**
     * @brief Obtém uma referência constante ao pixel numa dada posição (x, y).
     *
     * Não permite modificar a cor do pixel.
     *
     * @param x Coordenada x (coluna) do pixel.
     * @param y Coordenada y (linha) do pixel.
     * @return Referência constante ao objeto Color na posição (x, y).
     */

    const Color &Image::at(int x, int y) const {
        return pixels_val[y][x];
    }
}