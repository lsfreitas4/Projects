#include "Command/VMirror.hpp"
#include "Image.hpp"
#include <algorithm>

namespace prog {

    /**
     * @brief Construtor da classe VMirror.
     *
     * Inicializa o comando para espelhamento vertical da imagem.
     */
    VMirror::VMirror() : Command("v_mirror") {}

    /**
     * @brief Aplica o comando de espelhamento vertical na imagem.
     *
     * Inverte verticalmente os pixels da imagem, trocando os pixels da parte superior
     * pelos correspondentes da parte inferior.
     *
     * @param img Ponteiro para a imagem a ser espelhada.
     * @return Ponteiro para a imagem modificada.
     *         Se img for nullptr, retorna nullptr.
     */
    Image* VMirror::apply(Image* img) {
        if (img == nullptr) {
            return nullptr;
        }

        int width = img->width();
        int height = img->height();
        int half_height = height / 2;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < half_height; y++) {
                int mirror_y = height - 1 - y;
                std::swap(img->at(x, y), img->at(x, mirror_y));
            }
        }

        return img;
    }

}
