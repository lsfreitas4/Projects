#include "gtest/gtest.h"
#include "gmock/gmock.h"

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include "classesPerUc.h"
#include "students.h"
#include "schedule.h"
#include "blocks.h"
#include "readFromTextFiles.h"
#include "classes.h"

void clearScreen() {
    std::cout << "\033[2J\033[1;1H";
}
void ocupacaoTurmaUc(Schedule& schedule) {
    std::string ucCode, classCode;
    std::cout << "Código da UC (no formato L.EIC???)" << std::endl;
    std::cin >> ucCode;
    if (ucCode.length() == 8 ||ucCode.substr(0,5) == "L.EIC") {
        std::cout << "Código da turma (no formato ?LEIC??)" << std::endl;
        std::cin >> classCode;
        if (classCode.length() != 7 ||classCode.substr(1,4) != "LEIC") {
            std::cout << "Formato incorreto. Tente novamente. \n" << std::endl;
            return;
        }
        schedule.printDetailsUcClass(ClassesPerUc(ucCode, classCode));
    }
    else {
        std::cout << "\n Formato incorreto. Tente novamente. \n" << std::endl;
        return;
    }
}

void mainMenu() {
    clearScreen();
    std::cout << " ------------------------------------------------------------------------- " << std::endl;
    std::cout << "|                                                                         |" << std::endl;
    std::cout << "|                        Selecione uma opcção                             |" << std::endl;
    std::cout << "|                                                                         |" << std::endl;
    std::cout << "|     opção 1 - Ocupação de determinada turma de uma determinada Uc       |" << std::endl;
    std::cout << "|     opção 2 - Horário do estudante                                      |" << std::endl;
    std::cout << "|     opção 3 - Ordenações                                                |" << std::endl;
    std::cout << "|     opção 4 - Pedidos de alteração                                      |" << std::endl;
    std::cout << "|                                                                         |" << std::endl;
    std::cout << "|                              5 - Exit                                   |" << std::endl;
    std::cout << " ------------------------------------------------------------------------- " << std::endl;

    int input;
    std::cin >> input;

    clearScreen();


    switch (input) {
        case 1:

            std::cout << ocupacaoTurmaUc(&) << std::endl;
            // volta ao menu principal
            std::cout << std::endl <<std::endl << "Prima 1 para voltar ao Menu anterior..." << std::endl;
            std::cin >> input;
            mainMenu();
            break;
        case 2:
            std::cout << "Numero de estudante" << std::endl;
            std::cin >> n;
            if(n.length() == 9) {
                schedule.printSch(stoi(n));
                std::cout << std::endl <<std::endl << "Prima 1 para voltar ao Menu anterior ..." << std::endl;
                std::cin >> input;
                mainMenu();
                break;
            }
            else {
                std::cout << "Formato incorreto. Tente novamente." << std::endl;
                break;
            }
        case 3:

            // voltar ao menu principal
            std::cout << std::endl <<std::endl << "Prima 1 para voltar ao Menu anterior..." << std::endl;
            std::cin >> input;
            mainMenu();
            break;
        case 4:


            // voltar ao menu principal
            std::cout << std::endl <<std::endl << "Prima 1 para voltar ao Menu anterior..." << std::endl;
            std::cin >> input;
            mainMenu();
            break;
        case 5:
            break;
        default:
            std::cout << "Wrong Input" << std::endl;
            mainMenu();
    }
}

int main() {
    mainMenu();
    return 0;
}