#include "Command/Invert.hpp"
#include "Image.hpp"
#include "Color.hpp"

namespace prog {
    /**
     * @brief Construtor da classe Invert.
     *
     * Inicializa o comando para inverter as cores da imagem.
     */

    Invert::Invert() : Command("invert") {}

    /**
     * @brief Aplica o comando de inversão de cores na imagem.
     *
     * Para cada pixel da imagem, inverte as componentes RGB da cor,
     * ou seja, calcula 255 menos o valor original para cada canal.
     *
     * @param img Ponteiro para a imagem a ser invertida.
     * @return Ponteiro para a imagem modificada.
     */
    Image* Invert::apply(Image* img) {
        if (img == nullptr) return nullptr;

        for (int y = 0; y < img->height(); y++) {
            for (int x = 0; x < img->width(); x++) {
                Color original = img->at(x, y);
                Color inverted(255 - original.red(), 255 - original.green(), 255 - original.blue());
                img->at(x, y) = inverted;
            }
        }

        return img;
    }

} // namespace prog