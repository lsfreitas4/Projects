#include "Command/Replace.hpp"
#include "Image.hpp"

namespace prog {

    /**
     * @brief Construtor da classe Replace.
     *
     * Inicializa o comando para substituir uma cor por outra na imagem.
     *
     * @param from Cor a ser substituída.
     * @param to Cor que substituirá a cor original.
     */
    Replace::Replace(const Color& from, const Color& to) :
        Command("replace"), from_(from), to_(to) {}

    /**
     * @brief Aplica o comando de substituição de cores na imagem.
     *
     * Substitui todos os pixels cuja cor seja igual 'from' pela cor 'to'.
     * Se a imagem for nullptr, não realiza nenhuma operação.
     *
     * @param img Ponteiro para a imagem onde será efetuada a substituição.
     * @return Retorna o mesmo ponteiro para a imagem atualizada.
     */
    Image* Replace::apply(Image* img) {
        if (img == nullptr) {
            return nullptr;
        }

        for (int y = 0; y < img->height(); y++) {
            for (int x = 0; x < img->width(); x++) {
                Color& current = img->at(x, y);
                if (current.red() == from_.red() &&
                    current.green() == from_.green() &&
                    current.blue() == from_.blue()) {
                    current = to_;
                    }
            }
        }

        return img;
    }

}
